from django.apps import AppConfig


class AsteroidappConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "asteroidapp"
