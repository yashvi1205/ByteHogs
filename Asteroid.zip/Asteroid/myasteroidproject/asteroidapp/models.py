from django.db import models

class Asteroid(models.Model):
    name = models.CharField(max_length=100)
    size = models.FloatField(help_text="Size in meters")
    velocity = models.FloatField(help_text="Velocity in km/s")
    distance_to_earth = models.FloatField(help_text="Distance to Earth in km")
    detection_time = models.DateTimeField(auto_now_add=True)

    def _str_(self):
        return self.name
    
class Tracking(models.Model):
    asteroid = models.ForeignKey(Asteroid, on_delete=models.CASCADE)
    trajectory = models.TextField(help_text="3D coordinates for trajectory")
    last_tracked = models.DateTimeField(auto_now=True)

    def _str_(self):
        return f"Tracking {self.asteroid.name}"
    
class ImpactPrediction(models.Model):
    asteroid = models.ForeignKey(Asteroid, on_delete=models.CASCADE)
    impact_probability = models.FloatField(help_text="Impact probability as a percentage")
    estimated_damage = models.FloatField(help_text="Estimated damage in USD")
    affected_areas = models.TextField(help_text="List of affected areas")

    def _str_(self):
        return f"Prediction for {self.asteroid.name}"
    
class ResponseStrategy(models.Model):
    RESPONSE_CHOICES = [
        ('Deflection', 'Deflection'),
        ('Destruction', 'Destruction'),
    ]
    asteroid = models.ForeignKey(Asteroid, on_delete=models.CASCADE)
    strategy = models.CharField(max_length=20, choices=RESPONSE_CHOICES)
    success_probability = models.FloatField(help_text="Success probability as a percentage")
    execution_time = models.DateTimeField()

    def _str_(self):
        return f"{self.strategy} for {self.asteroid.name}"
