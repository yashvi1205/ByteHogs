from django.shortcuts import render
from .models import Asteroid
from .models import Tracking
from .models import ImpactPrediction
from .models import ResponseStrategy


def home(request):
    return render(request, 'home.html')

def detection(request):
    # asteroids = Asteroid.objects.all()
    return render(request, 'detection.html')

def tracking(request):
    # trackings = Tracking.objects.select_related('asteroid').all()
    return render(request, 'tracking.html')

def prediction(request):
    # predictions = ImpactPrediction.objects.select_related('asteroid').all()
    return render(request, 'prediction.html')

def response(request):
    strategies = ResponseStrategy.objects.select_related('asteroid').all()
    return render(request, 'response/response.html', {'strategies': strategies})

def about(request):
    return render(request, 'about.html')

def contact(request):
    return render(request, 'contact.html')
# Create your views here.
